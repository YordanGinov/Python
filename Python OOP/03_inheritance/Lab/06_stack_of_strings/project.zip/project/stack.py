class Stack():
    def __init__(self, *args) -> None:
        self.data = [str(el) for el in args]

    def push(self, element: str) -> None:
        self.data.append(str(element))

    def pop(self) -> None:
        self.data.pop()

    def top(self) -> str:
        return self.data[-1]

    def is_empty(self) -> bool:
        return any(self.data)

    def __str__(self) -> str:
        return "[" + ", ".join(reversed(self.data)) + "]"